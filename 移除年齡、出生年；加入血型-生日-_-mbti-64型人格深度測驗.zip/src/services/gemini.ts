import { GoogleGenAI } from "@google/genai";
import { animalData } from "../data/animals";

export interface MBTIResult {
  name: string;
  gender: string;
  birthday: string;
  bloodType: string;
  zodiac: string;
  typeCode: string; // e.g., INTJ-A-H
  scores: {
    EI: number;
    SN: number;
    TF: number;
    JP: number;
    AO: number;
    HC: number;
  };
}

export async function getDeepAnalysis(result: MBTIResult) {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is not configured");
  }

  const ai = new GoogleGenAI({ apiKey });
  const model = "gemini-3-flash-preview";
  
  const animalInfo = animalData[result.typeCode] || { animal: "未知動物", emoji: "✨", groupName: "未知", suffixName: "未知" };

  const prompt = `
    受測者資訊：
    姓名：${result.name}
    性別：${result.gender}
    生日：${result.birthday}
    星座：${result.zodiac}
    血型：${result.bloodType}
    MBTI 64型結果代碼：${result.typeCode}
    精神圖騰（代表動物）：${animalInfo.animal} ${animalInfo.emoji} (${animalInfo.groupName} - ${animalInfo.suffixName})
    各維度得分（0-100，越高代表越傾向第一項）：
    能量 (E/I): ${result.scores.EI}%
    資訊 (S/N): ${result.scores.SN}%
    決策 (T/F): ${result.scores.TF}%
    執行 (J/P): ${result.scores.JP}%
    壓力 (A/O): ${result.scores.AO}%
    社交 (H/C): ${result.scores.HC}%

    請針對此結果，進行深度的人格與職場潛力分析。這不是一般的 MBTI 分析，請務必「深度融合」受測者的【代表動物（${animalInfo.animal}）】、【星座（${result.zodiac}）】與【血型（${result.bloodType}）】特質，探討這些元素如何交互影響其在職場上的表現。

    請從「企業營運」、「職場競爭力」與「領導力」的角度，生成一份字數嚴格控制在 600-800 字之間的繁體中文深度解析報告。
    報告結構應包含：
    1. 🌟 精神圖騰賦能：開篇即以代表動物「${animalInfo.animal}」的形象切入，結合 MBTI (${result.typeCode})、${result.zodiac}與${result.bloodType}血型，描繪出何種獨特、生動的職場性格樣貌與競爭優勢？（例如：某動物的天性加上某星座的直覺與某血型的務實，會產生什麼化學反應）。
    2. 🤝 團隊佈局與協作洞察：在團隊中，這樣的組合展現出何種領導風格或協作模式？是團隊的守護者、開創者還是潤滑劑？
    3. 🎯 最佳發揮場域：基於上述綜合特質，最適合的職業發展方向、企業文化或具體角色定位。
    4. 💡 突破盲點的成長策略：針對此組合可能產生的盲點或潛在風險，提供 2-3 項「具體、可立即落地執行」的行動指引（Actionable Advice），避免空泛的建議，讓受測者能直接應用於日常工作中。

    請以專業、具畫面感、溫潤且具啟發性的語氣撰寫，並使用 Markdown 格式排版（可適度使用標題、粗體與列表，讓閱讀體驗更好）。請務必確保總字數落在 600 至 800 字之間，字字珠璣，提供最精煉實用的洞察。
  `;

  try {
    const response = await ai.models.generateContent({
      model,
      contents: prompt,
    });
    return response.text;
  } catch (error) {
    console.error("Gemini API Error:", error);
    throw error;
  }
}
